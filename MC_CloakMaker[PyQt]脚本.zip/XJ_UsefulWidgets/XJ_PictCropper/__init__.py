

from .XJ_SampleCropper import XJ_SampleCropper as XJ_PictCropper

__all__=['XJ_PictCropper']
