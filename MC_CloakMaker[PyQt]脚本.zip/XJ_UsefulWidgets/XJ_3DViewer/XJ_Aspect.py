from enum import Enum

class XJ_Aspect(Enum):#前后左右上下，立方体的六面
    Front=0
    Back=5
    Left=1
    Right=4
    Top=2
    Bottom=3
